const DAYS=["Monday","Tuesday","Wednesday","Thursday","Friday"];
const PERIODS=["P1 · 9:00","P2 · 10:00","P3 · 11:00","P4 · 12:00","P5 · 1:30","P6 · 2:30"];
let subjects=[],faculty=[],rooms=[],allocations=[];
const $=id=>document.getElementById(id);
const save=()=>localStorage.setItem("classclockwork",JSON.stringify({subjects,faculty,rooms,allocations}));
const load=()=>{try{const x=JSON.parse(localStorage.getItem("classclockwork"));if(x){subjects=x.subjects||[];faculty=x.faculty||[];rooms=x.rooms||[];allocations=x.allocations||[]}}catch{}};
function id(){return Math.random().toString(36).slice(2,9)}
function notify(msg,bad=false){$("status").textContent=msg;$("status").className="status"+(bad?" error":"")}
function render(){
 $("subjectCount").textContent=subjects.length;$("facultyCount").textContent=faculty.length;$("roomCount").textContent=rooms.length;
 $("subjectFaculty").innerHTML=faculty.map(f=>`<option value="${f.id}">${f.name}</option>`).join("");
 $("subjectList").innerHTML=subjects.map(s=>`<li>${s.name} · ${s.batch}<span class="remove" data-del="s" data-id="${s.id}">×</span></li>`).join("")||"<li>None added</li>";
 $("facultyList").innerHTML=faculty.map(f=>`<li>${f.name} · max ${f.limit}<span class="remove" data-del="f" data-id="${f.id}">×</span></li>`).join("")||"<li>None added</li>";
 $("roomList").innerHTML=rooms.map(r=>`<li>${r.name} · ${r.type} · ${r.capacity} seats<span class="remove" data-del="r" data-id="${r.id}">×</span></li>`).join("")||"<li>None added</li>";
 const mode=$("viewMode").value,old=$("viewPerson").value,items=mode==="batch"?[...new Set(subjects.map(s=>s.batch))]:faculty.map(f=>f.id);
 $("viewPerson").innerHTML=items.map(v=>mode==="batch"?`<option>${v}</option>`:`<option value="${v}">${faculty.find(f=>f.id===v)?.name||""}</option>`).join("");
 if(items.includes(old))$("viewPerson").value=old;
 renderGrid();save();
}
function conflicts(a,ignoreId=null){
 const s=subjects.find(x=>x.id===a.subjectId),f=faculty.find(x=>x.id===s?.facultyId),r=rooms.find(x=>x.id===a.roomId);
 if(!s||!f||!r)return ["Missing resource"];
 const errors=[];
 if(r.type!==s.roomType)errors.push("Room type mismatch");
 if(r.capacity< (s.batch.startsWith("CSE")?50:30))errors.push("Room capacity may be insufficient");
 if(f.unavailable===`${a.day}-${a.period}`)errors.push("Faculty unavailable");
 for(const b of allocations){if(b.id===ignoreId||b.day!==a.day||b.period!==a.period)continue;
  const bs=subjects.find(x=>x.id===b.subjectId);
  if(b.roomId===a.roomId)errors.push("Room already booked");
  if(bs?.facultyId===s.facultyId)errors.push("Faculty already booked");
  if(bs?.batch===s.batch)errors.push("Batch already has a class");
 }
 return [...new Set(errors)];
}
function renderGrid(){
 const mode=$("viewMode").value,who=$("viewPerson").value;
 let html="<thead><tr><th>Day / Period</th>"+PERIODS.map(p=>`<th>${p}</th>`).join("")+"</tr></thead><tbody>";
 DAYS.forEach((day,d)=>{html+=`<tr><th>${day}</th>`;for(let p=0;p<6;p++){
  const a=allocations.find(x=>x.day===d&&x.period===p&&(()=>{const s=subjects.find(z=>z.id===x.subjectId);return mode==="batch"?s?.batch===who:s?.facultyId===who})());
  if(!a){html+=`<td data-day="${d}" data-period="${p}"><div class="empty">Drop class here</div></td>`;continue}
  const s=subjects.find(x=>x.id===a.subjectId),f=faculty.find(x=>x.id===s.facultyId),r=rooms.find(x=>x.id===a.roomId),err=conflicts(a,a.id);
  html+=`<td data-day="${d}" data-period="${p}"><div class="slot ${s.roomType==="lab"?"lab":""} ${err.length?"conflict":""}" draggable="true" data-aid="${a.id}"><strong>${s.name}</strong>${s.batch}<small>${f?.name||""}</small><small>${r?.name||""}</small>${err.length?`<small>⚠ ${err.join(", ")}</small>`:""}</div></td>`;
 }html+="</tr>"});html+="</tbody>";$("timetable").innerHTML=html;
 $("clashCount").textContent=allocations.reduce((n,a)=>n+ (conflicts(a,a.id).length?1:0),0);
}
function generate(){
 if(!subjects.length||!faculty.length||!rooms.length){notify("Add at least one subject, faculty member and room first.",true);return}
 allocations=[];
 const tasks=subjects.flatMap(s=>Array.from({length:s.periods},(_,i)=>({subjectId:s.id,part:i})));
 tasks.sort((a,b)=>{const sa=subjects.find(x=>x.id===a.subjectId),sb=subjects.find(x=>x.id===b.subjectId);return (sb.roomType==="lab")-(sa.roomType==="lab")});
 let nodes=0;
 function solve(i){
  if(i===tasks.length)return true;if(++nodes>180000)return false;
  const task=tasks[i],s=subjects.find(x=>x.id===task.subjectId),f=faculty.find(x=>x.id===s.facultyId);
  if(!f)return false;
  const slots=[];for(let d=0;d<5;d++)for(let p=0;p<6;p++)slots.push({day:d,period:p});
  // MRV-style preference: try periods with fewer existing allocations first.
  slots.sort((a,b)=>allocations.filter(x=>x.day===a.day&&x.period===a.period).length-allocations.filter(x=>x.day===b.day&&x.period===b.period).length);
  for(const slot of slots){
   const room=rooms.find(r=>r.type===s.roomType&&r.capacity>=(s.batch.startsWith("CSE")?50:30));
   if(!room)continue;
   const a={id:id(),subjectId:s.id,roomId:room.id,...slot};
   if(conflicts(a).length)continue;
   const count=allocations.filter(x=>subjects.find(z=>z.id===x.subjectId)?.facultyId===f.id).length;
   if(count>=f.limit)continue;
   allocations.push(a);if(solve(i+1))return true;allocations.pop();
  }return false;
 }
 const ok=solve(0);
 if(ok){notify(`Timetable generated successfully in ${nodes.toLocaleString()} search steps. No clashes detected.`)}
 else{allocations=[];notify("Could not place every class with the current constraints. Add rooms or faculty availability, or reduce weekly periods.",true)}
 render();
}
$("facultyForm").addEventListener("submit",e=>{e.preventDefault();faculty.push({id:id(),name:$("facultyName").value.trim(),limit:+$("facultyLimit").value,unavailable:$("facultyUnavailable").value});e.target.reset();render()});
$("roomForm").addEventListener("submit",e=>{e.preventDefault();rooms.push({id:id(),name:$("roomName").value.trim(),capacity:+$("roomCapacity").value,type:$("roomType").value});e.target.reset();render()});
$("subjectForm").addEventListener("submit",e=>{e.preventDefault();if(!faculty.length){notify("Add a faculty member first.",true);return}subjects.push({id:id(),name:$("subjectName").value.trim(),batch:$("subjectBatch").value.trim(),facultyId:$("subjectFaculty").value,periods:+$("subjectPeriods").value,roomType:$("subjectRoomType").value});e.target.reset();render()});
document.addEventListener("click",e=>{const x=e.target.closest("[data-del]");if(!x)return;const {del,id:rid}=x.dataset;if(del==="s"){subjects=subjects.filter(x=>x.id!==rid);allocations=allocations.filter(a=>a.subjectId!==rid)}if(del==="f"){faculty=faculty.filter(x=>x.id!==rid);subjects=subjects.filter(s=>s.facultyId!==rid);allocations=allocations.filter(a=>subjects.some(s=>s.id===a.subjectId))}if(del==="r"){rooms=rooms.filter(x=>x.id!==rid);allocations=allocations.filter(a=>a.roomId!==rid)}render()});
$("generate").onclick=generate;$("viewMode").onchange=render;$("viewPerson").onchange=renderGrid;$("printBtn").onclick=()=>window.print();
let dragged=null;
$("timetable").addEventListener("dragstart",e=>{const card=e.target.closest("[data-aid]");if(card)dragged=card.dataset.aid});
$("timetable").addEventListener("dragover",e=>{if(e.target.closest("td[data-day]"))e.preventDefault()});
$("timetable").addEventListener("drop",e=>{const cell=e.target.closest("td[data-day]");if(!cell||!dragged)return;e.preventDefault();const a=allocations.find(x=>x.id===dragged);const next={...a,day:+cell.dataset.day,period:+cell.dataset.period};const errors=conflicts(next,a.id);if(errors.length){notify("Clash: "+errors.join(", "),true);return}Object.assign(a,next);notify("Class moved successfully. No clash detected.");renderGrid();save();dragged=null});
$("exportICS").onclick=()=>{const lines=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//ClassClockwork//Timetable//EN"];allocations.forEach(a=>{const s=subjects.find(x=>x.id===a.subjectId),f=faculty.find(x=>x.id===s.facultyId),r=rooms.find(x=>x.id===a.roomId);const day=new Date();const monday=new Date(day);monday.setDate(day.getDate()-((day.getDay()+6)%7));const start=new Date(monday);start.setDate(start.getDate()+a.day);start.setHours(9+a.period+(a.period>=4?.5:0),0,0,0);const end=new Date(start);end.setMinutes(end.getMinutes()+50);const fmt=d=>d.toISOString().replace(/[-:]/g,"").replace(/\.\d{3}/,"");lines.push("BEGIN:VEVENT","UID:"+a.id+"@classclockwork","DTSTART:"+fmt(start),"DTEND:"+fmt(end),"SUMMARY:"+s.name+" - "+s.batch,"DESCRIPTION:"+f.name+" / "+r.name,"END:VEVENT")});lines.push("END:VCALENDAR");download("classclockwork.ics",lines.join("\r\n"),"text/calendar")};
function download(name,data,type){const blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
$("loadDemo").onclick=()=>{faculty=[{id:"f1",name:"Dr. Sharma",limit:18,unavailable:""},{id:"f2",name:"Prof. Rao",limit:18,unavailable:""},{id:"f3",name:"Dr. Mehta",limit:16,unavailable:""},{id:"f4",name:"Prof. Iyer",limit:18,unavailable:""},{id:"f5",name:"Dr. Khan",limit:16,unavailable:""}];rooms=[{id:"r1",name:"Room 101",capacity:60,type:"classroom"},{id:"r2",name:"Room 102",capacity:60,type:"classroom"},{id:"r3",name:"Room 201",capacity:60,type:"classroom"},{id:"r4",name:"CS Lab 1",capacity:60,type:"lab"}];subjects=[{id:"s1",name:"Data Structures",batch:"CSE-A",facultyId:"f1",periods:3,roomType:"classroom"},{id:"s2",name:"Operating Systems",batch:"CSE-A",facultyId:"f2",periods:3,roomType:"classroom"},{id:"s3",name:"OS Lab",batch:"CSE-A",facultyId:"f2",periods:2,roomType:"lab"},{id:"s4",name:"Database Systems",batch:"CSE-A",facultyId:"f3",periods:3,roomType:"classroom"},{id:"s5",name:"Computer Networks",batch:"CSE-B",facultyId:"f1",periods:3,roomType:"classroom"},{id:"s6",name:"Python Programming",batch:"CSE-B",facultyId:"f4",periods:3,roomType:"classroom"},{id:"s7",name:"Python Lab",batch:"CSE-B",facultyId:"f4",periods:2,roomType:"lab"},{id:"s8",name:"Mathematics",batch:"CSE-B",facultyId:"f5",periods:3,roomType:"classroom"}];allocations=[];render();generate()};
load();render();