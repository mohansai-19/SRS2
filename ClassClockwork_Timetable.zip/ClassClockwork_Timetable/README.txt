# ClassClockwork Timetable Generator

## Run in VS Code
1. Extract `ClassClockwork_Timetable.zip`.
2. Open the extracted `ClassClockwork_Timetable` folder in Visual Studio Code.
3. Open `index.html` in your browser, or install the **Live Server** extension.
4. Right-click `index.html` and choose **Open with Live Server**.

## Included features
- Add subjects, faculty, classrooms and labs.
- Generate a 5-day × 6-period weekly timetable using a backtracking search.
- Check faculty, room and batch clashes.
- Switch between batch and faculty views.
- Drag timetable cards to another slot with instant validation.
- Print or save as PDF using the browser print dialog.
- Export calendar entries as an `.ics` file.
- Save data in browser localStorage.
- Load sample demo data.

## Notes
This is a front-end HTML/CSS/JavaScript prototype. It stores data in the current browser and does not require Node.js or a database. The sample capacity rule uses 50 seats for batches whose name starts with `CSE`, and 30 for other batches; adjust the `conflicts()` function in `script.js` if your project needs a different batch-size input.
